BLOX FRUITS MENU - مشروع Android

المحتويات:
- app/src/main/assets/menu.jpg : الصورة الأصلية التي أرسلتها.
- app/src/main/assets/index.html : واجهة القائمة والأزرار التفاعلية.
- app/src/main/java/.../MainActivity.kt : تطبيق Android WebView.
- ملفات Gradle لإعداد مشروع Android Studio.

طريقة بناء APK:
1) ثبّت Android Studio على الكمبيوتر.
2) فك ضغط BloxFruitsMenuAPK.zip.
3) افتح مجلد BloxFruitsMenu في Android Studio عبر Open.
4) وافق على تنزيل مكونات Gradle و Android SDK المطلوبة (compileSdk 35).
5) اختر Build > Build Bundle(s) / APK(s) > Build APK(s).
6) بعد نجاح البناء سيظهر APK في:
   app/build/outputs/apk/debug/app-debug.apk

طريقة التشغيل:
- ثبّت APK على هاتف Android.
- التطبيق يفتح أفقياً وبملء الشاشة.
- اضغط بطاقة PIRATES أو MARINES لاختيار الفريق (يعرض تأكيداً فقط حالياً).
- اضغط Fast Mode لتبديل حالته (ON/OFF).

ملاحظة مهمة:
هذا المشروع ينشئ واجهة القائمة فقط كما طلبت، وليس لعبة Blox Fruits كاملة.
لا توجد حالياً خريطة لعب أو قتال أو نظام فواكه أو اتصال بخوادم Roblox.
هذا ZIP هو مشروع Android Studio قابل للبناء، وليس ملف APK مُجمّعاً.
